import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.swing.*;
import javax.swing.border.Border;

public class QuizGame extends JFrame {
    private List<String[]> questions; 
    private List<String[]> askedQuestions; 
    private int points; 
    private JTextArea questionArea; 
    private boolean categorySelected; 
    private JButton[][] matrix;
    private boolean[][] hasApple; 
    private JButton upButton, downButton, leftButton, rightButton, selectButton;
    private int selectedRow = 0; 
    private int selectedCol = 0; 
    private ImageIcon buttonImage; 
    private ImageIcon handCursor; 
    private ImageIcon currentImage;
    private ImageIcon emptyImage; 
    private JLabel pointsLabel; 
    private int points1; 
    private JLabel basketLabel; 
    Timer timer; 

    public QuizGame() throws FileNotFoundException {
        this.setTitle("Apple Hunter"); 
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);

        ImagePanel image = new ImagePanel("background.jpg"); 
        image.setBounds(0, 0, 1920, 1080); 
        JPanel panel = new JPanel(); 
        panel.setLayout(new GridLayout(20, 1)); 
        panel.setOpaque(false); 

        for (int i = 0; i < 6; i++) { 
            JPanel emptyPanel = new JPanel();
            emptyPanel.setOpaque(false); 
            panel.add(emptyPanel);
        }

        JLabel categoryLabel = new JLabel("<html><font size='6'>Please select a difficulty:</font></html>");
        panel.add(categoryLabel);

        ButtonGroup categoryGroup = new ButtonGroup();
        for (int i = 1; i <= 3; i++) { 
            String difficulty = null;
            if (i == 1) {
                difficulty = "Easy Questions";
            } else if (i == 2) {
                difficulty = "Moderate Questions";
            } else if (i == 3) {
                difficulty = "Difficult Questions";
            }
            JRadioButton radioButton = new JRadioButton("<html><font size='5'> " + difficulty + "</font></html>"); 
            radioButton.setOpaque(false); 
            radioButton.setActionCommand(Integer.toString(i));
            radioButton.setSize(150, 25); 
            categoryGroup.add(radioButton); 
            panel.add(radioButton); 
        }

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false); 

        JButton startQuizButton = new JButton("Start Quiz");
        startQuizButton.setSize(100, 25);        
        startQuizButton.setBorder(new RoundedBorder(10)); 
        startQuizButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int category = Integer.parseInt(categoryGroup.getSelection().getActionCommand());
                if (!categorySelected) { 
                    categorySelected = true; 
                }
                startQuiz(category); 
            }
        });
        buttonPanel.add(startQuizButton); 

        JButton startGameButton = new JButton("Start Play Game");
        startGameButton.setSize(100, 25); 
        startGameButton.setBorder(new RoundedBorder(10)); 
        startGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { 
                if(points > 0){ 
                    startPlayGame(); 
                } else {
                    JOptionPane.showMessageDialog(null, "You have to earn points to be able to play the game."); 
                }
            }
        });
        buttonPanel.add(startGameButton); 

        panel.add(buttonPanel); 
        panel.setOpaque(false); 

        questionArea = new JTextArea(); 
        questionArea.setEditable(false); 

        image.add(panel); 
        this.add(image);
        
        initializeQuestions(); 

        buttonImage = new ImageIcon("apple.jpg"); 
        handCursor = new ImageIcon("hand.jpg"); 
        currentImage = buttonImage; 
    }

    private void initializeQuestions() throws FileNotFoundException { 
        questions = new ArrayList<>(); 
        askedQuestions = new ArrayList<>();
        
        File questionsFile = new File("questions.txt"); 
       
        if (!questionsFile.exists() || questionsFile.length() == 0) {
            return;
        }

        Scanner scanner = new Scanner(questionsFile);    
        while (scanner.hasNextLine()) { 
            String question = scanner.nextLine(); 
            questions.add(question.split(",")); 
        }
        scanner.close(); 
    }
    
    private void startQuiz(int category) { 
        if (questions.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Questions Not Found!");
            return;
        }

        Random random = new Random(); 
        List<String[]> categoryQuestions = new ArrayList<>(); 
        for (String[] question : questions) { 
            if (Integer.parseInt(question[1]) == category && !askedQuestions.contains(question)) {   
                categoryQuestions.add(question);                                                           
            }
        }

        if (categoryQuestions.isEmpty()) {                                                                     
        	 JOptionPane.showMessageDialog(this, "All questions answered. Total point: " + points);
            return;
        }

        String[] selectedQuestion = categoryQuestions.get(random.nextInt(categoryQuestions.size()));	
        askedQuestions.add(selectedQuestion); 
        String questionText = selectedQuestion[2]; 

        int optionCount = 4; 
        String[] options = new String[optionCount];	
        System.arraycopy(selectedQuestion, 3, options, 0, optionCount);  

        int result = JOptionPane.showOptionDialog(
                this,
                questionText,
                "Quiz Question",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );		

        if (options[result].equals(selectedQuestion[7])) { 
            if (category == 1) {
                points += 10; 
            } else if (category == 2) {
                points += 30; 
            } else if (category == 3) {
                points += 50; 
            } 

            JOptionPane.showMessageDialog(this, "Correct! Total Point: " + points); 
            startQuiz(category);
        } else {
            JOptionPane.showMessageDialog(this, "Incorrect! Total Point: " + points); 
            startQuiz(category);
        }
    }
	        
    private void startPlayGame() { 
        selectedRow=0; 
        selectedCol=0; 
        JFrame gameFrame = new JFrame("Play Game"); 
        gameFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        gameFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        gameFrame.setVisible(true);  

        JLabel timerLabel = new JLabel();  
        timerLabel.setPreferredSize(new Dimension(150, 20));

        matrix = new JButton[6][6];  
        hasApple = new boolean[6][6]; 
        JPanel matrixPanel = new JPanel();  
        matrixPanel.setBackground(Color.black); 
        matrixPanel.setLayout(new GridLayout(6, 6, 10, 10)); 
        Random random = new Random(); 
        for (int i = 0; i < 6; i++) { 
            for (int j = 0; j < 6; j++) { 
                matrix[i][j] = new JButton(); 
                matrix[i][j].setBackground(Color.black); 
                if (random.nextBoolean()) { 
                    if(i==0 && j==0) {
                    } else {
                        matrix[i][j].setIcon(buttonImage); 
                        hasApple[i][j] = true; 
                    }
                }
                matrix[i][j].setPreferredSize(new Dimension(30, 30)); 
                matrixPanel.add(matrix[i][j]); 
            }
        }
        matrix[0][0].setIcon(handCursor); 
        gameFrame.add(matrixPanel, BorderLayout.CENTER); 

        JPanel navigationPanel = new JPanel(); 
        navigationPanel.setLayout(new GridBagLayout()); 
        GridBagConstraints gbc = new GridBagConstraints();

        upButton = new JButton("^"); 
        gbc.gridx = 1; 
        gbc.gridy = 0; 
        upButton.addActionListener(new ActionListener() {  
            @Override
            public void actionPerformed(ActionEvent e) { 
                if (selectedRow > 0) { 
                    selectedRow--; 
                    selectCell(selectedRow, selectedCol); 
                }
            }
        });
        navigationPanel.add(upButton, gbc); 

        downButton = new JButton("v"); 
        gbc.gridx = 1; 
        gbc.gridy = 2;
        downButton.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                if (selectedRow < matrix.length - 1) {
                    selectedRow++; 
                    selectCell(selectedRow, selectedCol); 
                }
            }
        });
        navigationPanel.add(downButton, gbc); 

        leftButton = new JButton("<"); 
        gbc.gridx = 0;  
        gbc.gridy = 1;  
        leftButton.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                if (selectedCol > 0) { 
                    selectedCol--; 
                    selectCell(selectedRow, selectedCol); 
                }
            }
        });
        navigationPanel.add(leftButton, gbc); 
        rightButton = new JButton(">"); 
        gbc.gridx = 2; 
        gbc.gridy = 1; 
        rightButton.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                if (selectedCol < matrix[0].length - 1) { 
                    selectedCol++; 
                    selectCell(selectedRow, selectedCol); 
                }
            }
        });
        navigationPanel.add(rightButton, gbc); 

        selectButton = new JButton("•"); 
        gbc.gridx = 1; 
        gbc.gridy = 1; 
        selectButton.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                if (hasApple[selectedRow][selectedCol]) { 
                    matrix[selectedRow][selectedCol].setIcon(handCursor); 
                    hasApple[selectedRow][selectedCol] = false;
                    points1 += 100; 
                    pointsLabel.setText(" Score: " + points1); 
                    basketLabel.setText(" / Basket: " + "🍎".repeat(points1 / 100)); 

                    if (allApplesCollected()) { 
                        JOptionPane.showMessageDialog(gameFrame, "Congratulations! You have collected all the apples. Your score: " + points1); 
                        gameFrame.dispose(); 
                        points1=0;
                        timer.stop(); 
                    }
                }
            }
        });
      
        navigationPanel.add(selectButton, gbc); 

        JPanel southPanel = new JPanel(new BorderLayout()); 
        southPanel.add(navigationPanel, BorderLayout.CENTER); 
        southPanel.add(timerLabel, BorderLayout.EAST); 

        JPanel scorePanel = new JPanel();
        scorePanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        pointsLabel = new JLabel(" Score: 0"); 
        pointsLabel.setPreferredSize(new Dimension(80, 60)); 
        scorePanel.add(pointsLabel); 

        basketLabel = new JLabel("/ Basket: "); 
        basketLabel.setPreferredSize(new Dimension(500, 60)); 
        scorePanel.add(basketLabel); 

        southPanel.add(scorePanel, BorderLayout.WEST); 

        gameFrame.add(southPanel, BorderLayout.SOUTH); 

        int delay = points * 3 * 1000;
        timer = new Timer(delay, null); 

        timer.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                if (!allApplesCollected()) {
                    JOptionPane.showMessageDialog(gameFrame, "Time is up! Your Score: " + points1); 
                    gameFrame.dispose(); 
                    points1=0;
                }
            }
        });

        long startTime = System.currentTimeMillis(); 
        timer.setRepeats(false); 
        timer.start(); 

        new Timer(1000, new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                int elapsedSeconds = (int) ((System.currentTimeMillis() - startTime) / 1000); 
                int remainingSeconds = delay /1000  - elapsedSeconds; 
                if (remainingSeconds < 0) { 
                    remainingSeconds = 0; 		
                }
                timerLabel.setText("Time remaining: " + remainingSeconds + " sec"); 
            }
        }).start();
    }
    private void selectCell(int row, int col) { 
        for (int i = 0; i < matrix.length; i++) { 
            for (int j = 0; j < matrix[i].length; j++) { 
                if (hasApple[i][j]) {
                    matrix[i][j].setIcon(buttonImage);
                } else {
                    matrix[i][j].setIcon(null);
                } 
            }
        }
        matrix[row][col].setIcon(handCursor); 
    }

    private boolean allApplesCollected() { 
        for (int i = 0; i < hasApple.length; i++) { 
            for (int j = 0; j < hasApple[i].length; j++) { 
                if (hasApple[i][j]) { 
                    return false; 
                }
            }
        }
        return true; 
    }

    public static void main(String[] args) throws FileNotFoundException { 
        new QuizGame().setVisible(true);
    }

    class RoundedBorder implements Border { 
        private int radius;

        RoundedBorder(int radius) {
            this.radius = radius;
        }

        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
        }

        public boolean isBorderOpaque() {
            return true;
        }

        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }
    }

    class ImagePanel extends JPanel {
        private Image backgroundImage;

        public ImagePanel(String imagePath) {
            this.backgroundImage = new ImageIcon(imagePath).getImage();
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}










































